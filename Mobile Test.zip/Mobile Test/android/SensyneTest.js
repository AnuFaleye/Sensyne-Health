let wd = require('wd');
let assert = require('assert');
let asserters = wd.asserters;

desiredCaps = {
  // Set your BrowserStack access credentials
  'browserstack.user' : 'anufaleye1',
  'browserstack.key' : 'frkhqywsyQomqX4qYnWL',

  // Set URL of the application under test
  'app' : 'bs://b5e5f981c620298e3200b1e0fd7e62c00417646f',

  // Specify device and os_version for testing
  'device' : 'Google Pixel 3XL',
  'os_version' : '9.0',

  // Set other BrowserStack capabilities
  'project' : 'Sensyne Test',
  'build' : 'Node Android',
  'name': 'SensyneTest'
};

// Initialize the remote Webdriver using BrowserStack remote URL
// and desired capabilities defined above
driver = wd.promiseRemote("http://hub-cloud.browserstack.com/wd/hub");

driver
  .init(desiredCaps)
  //  Write your code here

  //Wait for 30 seconds for hospital list to display

   .then(function () {
    return driver.waitForElementByAccessibilityId(
      'com.sensynehealth.hospitals:id/hospitalName', asserters.isDisplayed 
      && asserters.isEnabled, 30000);
  })


  // Enter Walton Community Hospital into the Search field and click
  .then(function () {
    driver.waitForElementById('com.sensynehealth.hospitals:id/search_bar').click();
    return driver.waitForElementById('com.sensynehealth.hospitals:id/search_bar').sendKeys("Walton Community Hospital");
    driver.sendKeys(driver.Key.RETURN);
  })
 
  //Verifies Text Walton Community Hospital is displayed
  .then(function () {
    return driver.waitForElementByAccessibilityId(
      'com.sensynehealth.hospitals:text/Name: Walton Community Hospital', asserters.isDisplayed 
      && asserters.isEnabled, 30000);
  })

  .fin(function() { 
return driver.quit(); })
  .done();